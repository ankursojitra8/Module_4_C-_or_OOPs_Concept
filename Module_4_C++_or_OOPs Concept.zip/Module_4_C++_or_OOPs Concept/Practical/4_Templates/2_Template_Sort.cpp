// 2. WAP of to sort the array using templates

#include<iostream>
using namespace std;

int i, j;

template <typename T>
	void mySwap(T&a, T&b)
	{
    	T temp=a;
    	a=b;
    	b=temp;
	}

template <typename T>
	void sortArray(T arr[], int n) 
	{
    	for(i=0;i<n-1;i++)
    	{
        	for(j=0;j<n-i-1;j++)
        	{
            	if(arr[j]>arr[j+1])
                	mySwap(arr[j], arr[j+1]);
	        }
    	}
	}

template<typename T>
	void printArray(T arr[], int n) 
	{
    	for(i=0;i<n;i++)
    	{
        	cout<<arr[i]<<" ";
    	}
    	cout<<endl;
	}

main()
{
    int arr1[]={64, 34, 25, 12, 22, 11, 90};
    int n1=sizeof(arr1)/sizeof(arr1[0]);

    float arr2[] = {12.3, 45.6, 78.9, 10.1};
    int n2=sizeof(arr2)/sizeof(arr2[0]);

    cout<<"\n\n\t -------- INTEGER ARRAY BEFORE SORTING -------- \n\n\t  (1) \t";
    printArray(arr1, n1);
    sortArray(arr1, n1); 
    cout<<"\n\n\t *** Integer array after sorting *** \n\n\t -->> \t";
    printArray(arr1, n1);

    cout<<"\n\n\t---------------------------------------------------------------\n\n";
    cout<<"\n\n\t -------- FLOAT ARRAY BEFORE SORTING -------- \n\n\t  (2) \t";
    printArray(arr2, n2);
    sortArray(arr2, n2); 
    cout<<"\n\n\t *** Float array after sorting *** \n\n\t -->> \t";
    printArray(arr2, n2);
}

