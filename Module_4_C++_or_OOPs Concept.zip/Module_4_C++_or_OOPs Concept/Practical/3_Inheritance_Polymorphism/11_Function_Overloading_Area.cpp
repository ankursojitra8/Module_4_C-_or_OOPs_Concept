/* 11. WAP to calculate the area of circle, rectangle and triangle using Function Overloading
Rectangle : Area * breadth
Triangle : � *Area* breadth
Circle : Pi * Area *Area. */

#include<iostream>
using namespace std;

	double PI=3.14159;

	double calculateAreaCircle(double radius)
	{
    	return PI*radius*radius;
	}

	double calculateAreaRectangle(double length, double breadth)
	{
    	return length*breadth;
	}

	double calculateAreaTriangle(double base, double height)
	{
    	return 0.5*base*height;
	}

main()
{
    double r, l, b, b1, h;

    cout<<"\n\t |`-> Enter radius : ";
    cin>>r;
    cout<<"\n\n\t --> Area of circle : "<<calculateAreaCircle(r);
    cout<<"\n\n\t ------------------------------";

    cout<<"\n\n\t |`-> Enter length and breadth : ";
    cin>>l>>b;
    cout<<"\n\n\t --> Area of rectangle : "<<calculateAreaRectangle(l, b);
    cout<<"\n\n\t ------------------------------";

    cout<<"\n\n\t |`-> Enter base and height : ";
    cin>>b1>>h;
    cout<<"\n\n\t --> Area of triangle : "<<calculateAreaTriangle(b1, h);
    cout<<"\n\n\t ------------------------------";
}


