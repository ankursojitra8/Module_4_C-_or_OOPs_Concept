// 6. Write a C++ Program to show access to Private Public and Protected using Inheritance

#include<iostream>
using namespace std;

class Base
{
	public:
    		int public_data=10;
	protected:
    		int protected_data=20;
	private:
    		int private_data=30;
	public:
    		void displayPrivate()
			{
        		cout<<"\n\n\t --> Private data : "<<private_data;
    		}
};

class Derived:public Base
{
	public:
    		void accessMembers()
			{
    	    	cout<<"\n\n\t --> Public data : "<<public_data;
        		cout<<"\n\n\t --> Protected data : "<<protected_data; 
        		displayPrivate();
	    	}
};

main()
{
    Derived obj;
    obj.accessMembers();
}

