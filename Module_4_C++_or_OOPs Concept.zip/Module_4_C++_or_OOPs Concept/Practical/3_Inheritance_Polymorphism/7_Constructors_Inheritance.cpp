 // 7. Write a C++ Program to illustrates the use of Constructors in multilevel inheritance
 
#include<iostream>
using namespace std;

class Grandfather
{
	public:
    		Grandfather()
			{
	        	cout<<"\n\n------------ Illustrates The Use Of Constructors In Multilevel Inheritance ------------ ";
    	    	cout<<"\n\n\t --> Grandfather constructor is called ";
    		}
};

class Father:public Grandfather
{
	public:
    		Father()
			{
	        	cout<<"\n\n\t --> Father constructor is called ";
    		}
};

class Son:public Father
{
	public:
    		Son()
			{
	        	cout<<"\n\n\t --> Son constructor is called ";
    		}
};

main()
{
    Son s;
}

