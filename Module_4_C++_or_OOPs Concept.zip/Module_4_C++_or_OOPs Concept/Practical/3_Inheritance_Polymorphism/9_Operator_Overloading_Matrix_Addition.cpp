// 9. WAP of Two 1D Matrix Addition using Operator Overloading.

#include<iostream>
using namespace std;

class Matrix
{
	public:
    		int data[100], i, size;

    		Matrix(int arr[], int len):size(len)
			{
        		for(i=0;i<len;++i)
            		data[i]=arr[i];
    		}

	    	Matrix operator+(Matrix& other)
			{
        		if(size!=other.size)
				{
    	        	cout<<"Error: Matrix dimensions must be the same for addition";
        	    	return Matrix({0}, 0); 
	        	}

	        	Matrix result(data, size);
    	    		for (i=0;i<size;++i)
	        		{
    	        		result.data[i] = data[i] + other.data[i];
	        		}
		        	return result;
    		}

    		void print()
			{
        		for(i=0;i<size;++i)
				{
    	        	cout<<data[i]<<" ";
        		}
        		cout<<endl;
	    	}
};

main()
{
    int data1[]={1, 2, 3};
    int data2[]={4, 5, 6};

    Matrix matrix1(data1, sizeof(data1)/sizeof(data1[0]));
    Matrix matrix2(data2, sizeof(data2)/sizeof(data2[0]));
    Matrix result=matrix1+matrix2;
    result.print();
}

