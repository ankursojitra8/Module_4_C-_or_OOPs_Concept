/* 3. Create a class person having members name and age. Derive a class student  having member percentage. Derive 
another class teacher having member salary. Write necessary member function to initialize, read and write data.
Write also Main function (Multiple Inheritance)*/

#include<iostream>
#include<string>
using namespace std;

class Person
{
	protected:
    			string name;
    			int age;

	public:
    		void readPersonData()
			{
        		cout<<"\n\t |`-> Enter name : ";
	        	cin>>name;
    	    	cout<<"\n\t |`-> Enter age : ";
        		cin>>age;
    		}

	    	void displayPersonData()
			{
				cout<<"\n\n\t --------------------------------------";
        		cout<<"\n\n\t --> Name : "<<name;
	        	cout<<"\n\n\t --> Age : "<<age;
    		}
};

class Student:public Person
{
	protected:
    			float percentage;

	public:
    		void readStudentData()
			{
        		readPersonData();
	        	cout<<"\n\t |`-> Enter percentage: ";
    	    	cin>>percentage;
    		}

	    	void displayStudentData()
			{
        		displayPersonData();
        		cout<<"\n\n\t --> Percentage: "<<percentage;
	    	}
};

class Teacher:public Person
{
	protected:
    			float salary;

	public:
    		void readTeacherData()
			{
        		readPersonData();
	        	cout<<"\n\t |`-> Enter salary: ";
    	    	cin>>salary;
    		}

	    	void displayTeacherData()
			{
        		displayPersonData();
        		cout<<"\n\n\t --> Salary: "<<salary;
	    	}
};

main()
{
    Student student;
    Teacher teacher;

    cout<<"\n\n\t -->> Student Data <<-- ";
	cout<<"\n\n\t -------------------------------";
    student.readStudentData();
    student.displayStudentData();

	cout<<"\n\n\t -------------------------------";
    cout<<"\n\n\t -->> Teacher Data <<-- ";
	cout<<"\n\n\t -------------------------------";
    teacher.readTeacherData();
    teacher.displayTeacherData();
}

