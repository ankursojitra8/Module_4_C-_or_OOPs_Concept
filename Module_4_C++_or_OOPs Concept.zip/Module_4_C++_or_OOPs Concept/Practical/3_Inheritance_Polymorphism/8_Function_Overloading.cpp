/* 8. WAP to Mathematic operation like Addition, Subtraction, Multiplication, Division 
Of two number using different parameters and Function Overloading.*/

#include<iostream>
using namespace std;

	int add(int a, int b)
	{
    	return a+b;
	}

	double add(double a, double b)
	{
    	return a+b;
	}

	int subtract(int a, int b)
	{
    	return a-b;
	}

	double subtract(double a, double b)
	{
    	return a-b;
	}

	int multiply(int a, int b)
	{
    	return a*b;
	}

	double multiply(double a, double b)
	{
    	return a*b;
	}

	double divide(int a, int b)
	{
    	if(b==0)
		{
        	cout<<"\n\n\t *** Error Found : Division by zero is not allowed *** ";
        	return 0.0;
    	}
    	return (double)a/b;
	}

main()
{
    int num1_int = 10, num2_int = 5;
    double num1_double = 4.4, num2_double = 2.2;

    cout<<"\n\n\t --> Int addition: "<<add(num1_int, num2_int);
    cout<<"\n\t --> Double addition: "<<add(num1_double, num2_double);

    cout<<"\n\n\t --> Int subtraction: "<<subtract(num1_int, num2_int);
    cout<<"\n\t --> Double subtraction: "<<subtract(num1_double, num2_double);

    cout<<"\n\n\t --> Int multiplication: "<<multiply(num1_int, num2_int);
    cout<<"\n\t --> Double multiplication: "<<multiply(num1_double, num2_double);

    cout<<"\n\n\t --> Int division: "<<divide(num1_int, num2_int);
    cout<<"\n\t --> Double division: "<<divide(num1_double, num2_double);
}

