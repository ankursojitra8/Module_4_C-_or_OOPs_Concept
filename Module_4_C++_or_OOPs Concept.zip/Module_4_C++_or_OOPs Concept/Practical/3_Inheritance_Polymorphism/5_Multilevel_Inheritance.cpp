/*5. Assume that the test results of a batch of students are stored in three different  classes. Class Students 
are storing the roll number. Class Test stores the marks obtained in two subjects and class result contains the 
total marks obtained in the test. The class result can inherit the details of the marks obtained in the test and 
roll number of students. (Multilevel Inheritance)*/

#include<iostream>
using namespace std;

class Students
{
	protected:
    			int roll_no;

	public:
    		void setRollNo(int r)
			{
        		roll_no=r;
    		}
    		int getRollNo()
			{
        		return roll_no;
    		}
};

class Test
{
	protected:
    			int sub1, sub2;

	public:
    		void setMarks(int m1, int m2)
			{
        		sub1=m1;
        		sub2=m2;
    		}

	    	int getSub1()
			{
        		return sub1;
    		}

    		int getSub2()
			{
        		return sub2;
    		}
};

class Result : public Students, public Test
{
	private:
    		int total;

	public:
    		void calculateTotal()
			{
	        	total=getSub1()+getSub2();
    		}

    		void displayResult()
			{
    	    	cout<<"\n\n\t --> Roll No : "<<getRollNo();
        		cout<<"\n\n\t (1) Subject 1 : "<<getSub1();
        		cout<<"\n\n\t (2) Subject 2 : "<<getSub2();
	        	cout<<"\n\n\t --> Total Marks : "<<total;
    		}
};

main()
{
    Result result;
    result.setRollNo(101);
    result.setMarks(75, 80);
    result.calculateTotal();
    result.displayResult();
}

