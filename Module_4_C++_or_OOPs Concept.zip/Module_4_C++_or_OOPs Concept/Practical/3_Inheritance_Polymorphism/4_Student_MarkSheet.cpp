// 4. Write a C++ Program display Student Mark sheet using Multiple inheritance

#include<iostream>
#include<string>

using namespace std;

class Student
{
	protected:
    			string name;
    			int roll_no;

	public:
    		void readStudentData()
			{
        		cout<<"\n\t |`-> Enter Name : ";
	        	cin>>name;
    	    	cout<<"\n\t |`-> Enter Roll Number : ";
        		cin>>roll_no;
    		}

	    	void displayStudentData()
			{
				cout<<"\n\n\t ---------------------------------";
	    	    cout<<"\n\n\t --> Name : "<<name;
    		    cout<<"\n\n\t --> Roll No : "<<roll_no;
    		}
};

class Marks
{
	protected:
    			int maths, science, english;

	public:
    		void readMarks()
			{
        		cout<<"\n\t |`-> Enter marks for (1) Maths, (2) Science, (3) English : ";
	        	cin>>maths>>science>>english;
    		}

	    	void displayMarks()
			{
        		cout<<"\n\n\t  (1) Maths : "<<maths;
        		cout<<"\n\n\t  (2) Science : "<<science;
	        	cout<<"\n\n\t  (3) English : "<<english;
    		}
};

class StudentMarks:public Student, public Marks
{
	public:
    		void displayMarkSheet()
			{
    	    	displayStudentData();
	        	displayMarks();
    		}
};

main()
{
    StudentMarks student;

    student.readStudentData();
    student.readMarks();
    student.displayMarkSheet();
}

