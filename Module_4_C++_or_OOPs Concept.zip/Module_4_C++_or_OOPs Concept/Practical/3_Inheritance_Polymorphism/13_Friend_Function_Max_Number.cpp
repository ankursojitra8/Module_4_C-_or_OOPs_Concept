// 13. WAP to find the max number from given two numbers using friend function

#include<iostream>
using namespace std;

class Number
{
    	int num;

	public:
    		Number(int n):num(n) {}

    		friend int max(Number a, Number b);
};

	int max(Number a, Number b)
		{
    		return(a.num>b.num)?a.num:b.num;
		}

main()
{
    Number num1(10), num2(20);
    cout<<"\n\n\t --> Maximum number is : "<<max(num1, num2);
}

