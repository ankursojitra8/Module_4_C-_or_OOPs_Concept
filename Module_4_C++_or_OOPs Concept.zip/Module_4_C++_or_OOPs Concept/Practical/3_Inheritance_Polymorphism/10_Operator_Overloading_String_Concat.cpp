// 10. WAP to concatenate the two strings using Operator Overloading.

#include<iostream>
#include<string>
using namespace std;

class MyString
{
	public:
    	string str;
	
    	MyString(string s)
		{
        	str=s;
	    }

	    MyString operator+(MyString other)
		{
	        MyString temp;
    	    temp.str=str+other.str;
	        return temp;
	    }

	    void print()
		{
        	cout<<str;
	    }
};

main()
{
    MyString str1("Hello"), str2(" world");
    MyString result=str1+str2;
    result.print();
}



