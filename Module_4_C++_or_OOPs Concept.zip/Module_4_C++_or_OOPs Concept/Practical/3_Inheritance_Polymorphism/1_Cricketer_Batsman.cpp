/* 1. Assume a class cricketer is declared. Declare a derived class batsman from  cricketer. 
Data member of batsman. Total runs, Average runs and best performance. Member functions 
input data, calculate average runs, Display data. (Single Inheritance)*/

#include<iostream>
#include<string>
using namespace std;

class Cricketer
{
	public:
	    	string name;
    		int matches;

    		void inputCricketerData()
			{
    	    	cout<<"\n\t |`-> Enter name : ";
        		getline(cin, name);
	        	cout<<"\n\t |`-> Enter matches played : ";
    	    	cin>>matches;
    		}

	    	void displayCricketerData()
			{
				cout<<"\n\n\t ------------------------------";
	        	cout<<"\n\n\t --> Name : "<<name;
    	    	cout<<"\n\n\t --> Matches Played : "<<matches;
    		}
};

class Batsman:public Cricketer
{
	public:
    		int runs;
    		double average;
	    	int best;

    		void inputBatsmanData()
			{
	        	inputCricketerData();
    	    	cout<<"\n\t |`-> Enter total runs : ";
        		cin>>runs;
        		cout<<"\n\t |`-> Enter best performance : ";
	        	cin>>best;
    		}

    		void calculateAverage()
			{
	        	average = (double)runs / matches;
	    	}

    		void displayBatsmanData()
			{
    	    	displayCricketerData();
        		cout<<"\n\n\t --> Total Runs : "<<runs;
        		cout<<"\n\n\t --> Average Runs : "<<average;
	        	cout<<"\n\n\t --> Best Performance : "<<best;
    		}
};

main()
{
    Batsman batsman;
    batsman.inputBatsmanData();
    batsman.calculateAverage();
    batsman.displayBatsmanData();
}

