// 1. WAP to find the multiplication values and the cubic values using inline function

#include<iostream>
using namespace std;

inline int multiply(int a, int b)
	{
    	return a*b;
	}

inline int cube(int a)
	{
    	return a*a*a;
	}

main()
{
    int n1, n2;

    cout << "\n\n\t Enter two numbers : ";
    cin>>n1>>n2;

    int product=multiply(n1, n2);
    int cube1=cube(n1);
    int cube2=cube(n2);

    cout<<"\n\t-------------------------------";
    cout<<"\n\t --> Multiplication : "<<product;
    cout<<"\n\t --> Cube of first number : "<<cube1;
    cout<<"\n\t --> Cube of second number : "<<cube2;
}

