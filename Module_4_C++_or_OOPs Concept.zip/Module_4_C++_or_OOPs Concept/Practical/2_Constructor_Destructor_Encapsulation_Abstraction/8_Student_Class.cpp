/* 8. Write a C++ program to implement a class called Student that has private member variables for name, class,
roll number, and marks. Include member functions to calculate the grade based on the marks and display the student's 
information. Accept address from each student implement using of aggregation.*/

#include<iostream>
using namespace std;

class Student
{
    public:
        	string name;
	        int rollNumber;

    	    Student(string name, int rollNumber)
        	{
            	this->name=name;
            	this->rollNumber=rollNumber;
        	}
};

class Result
{
    private:
        	Student* stud;
    	    string className;
        	int marks;
        	char grade;

	        void calculateGrade()
    	    {
        	    if (marks>=90)
            	    grade='A+';
	            else if(marks>=80)
    	            grade='A';
        	    else if (marks>=70)
            	    grade='B';
	            else if (marks>=60)
    	            grade='C';
	            else if (marks>=34)
    	            grade='D';
        	    else
            	    grade='F';
	        }

    public:

    	    Result(string className, int marks, Student* stud)
        	{
            	this->className=className;
	            this->marks=marks;
    	        this->stud=stud;
        	    calculateGrade();
	        }

    	    void displayStudentInfo()
        	{
            	cout<<"\n\n\t--------------------------------";
	            cout<<"\n\n\t --> Name: "<<stud->name;
    	        cout<<"\n\n\t --> Roll Number: "<<stud->rollNumber;
        	    cout<<"\n\n\t --> Class: "<<className;
            	cout<<"\n\n\t --> Marks: "<<marks;
	            cout<<"\n\n\t --> Grade: "<<grade;
	        }
};

main()
{
    Student s("Ankur Sojitra", 21);
    Result r("10th Grade", 480 , &s);
    r.displayStudentInfo();
}

