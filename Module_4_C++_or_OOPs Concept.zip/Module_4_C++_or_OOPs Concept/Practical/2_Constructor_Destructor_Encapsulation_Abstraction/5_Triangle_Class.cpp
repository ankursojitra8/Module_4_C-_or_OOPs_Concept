/* 5. Write a C++ program to create a class called Triangle that has private  member variables for the lengths 
of its three sides. Implement member functions to determine if the triangle is equilateral, isosceles, or scalene.*/

#include<iostream>
using namespace std;

class Triangle
{
	private:
    		double side1, side2, side3;

	public:
    		Triangle(double s1, double s2, double s3)
			{
	        	side1=s1;
    	    	side2=s2;
        		side3=s3;
    		}

	    	string determineType()
			{
        		if(side1<=0||side2<=0||side3<=0)
            		return "\n\n\t *** Invalid Triangle : Side lengths must be positive *** ";
	        	else if(side1+side2<=side3||side2+side3<=side1||side1+side3<=side2)
    	        	return "\n\n\t *** Invalid Triangle : Triangle inequality violated *** ";
        		else if(side1==side2&&side2==side3)
            		return "\n\n\t -->> Equilateral Triangle ";
	        	else if(side1==side2||side2==side3||side1==side3)
    	        	return "\n\n\t -->> Isosceles Triangle ";
        		else
            		return "\n\n\t -->> Scalene Triangle ";
	    	}
};

main()
{
    double side1, side2, side3;

    cout<<"\n\t |`-> Enter the lengths of the three sides of the triangle : ";
    cin>>side1>>side2>>side3;

    Triangle triangle(side1, side2, side3);

    cout<<"\n\t -->> The triangle is a "<<triangle.determineType();
}

