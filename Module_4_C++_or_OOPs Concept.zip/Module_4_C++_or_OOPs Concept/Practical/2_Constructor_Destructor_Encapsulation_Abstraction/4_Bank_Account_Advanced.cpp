/* 4. Write a C++ program to implement a class called Bank Account that has private member variables for account 
number and balance. Include member functions to deposit and withdraw money from the account.*/

#include<iostream>
using namespace std;

class B_Account
{
	private:
    		int a_Number;
    		double balance;

	public:
    		B_Account(int acc_Number, double initial_Balance)
    		{
        		a_Number=acc_Number;
        		balance=initial_Balance;
    		}

    	void deposit(double amount)
    	{
        	if(amount>0)
        	{
            	balance+=amount;
            	cout<<"\n\n\t -->>> Deposit successful. -) New balance : $ "<<balance;
        	}
        	else
            	cout<<"\n\n\t *** Error : Invalid deposit amount. *** ";
    	}

    	void withdraw(double amount)
    	{
        	if(amount>0&&amount<=balance)
        	{
            	balance-=amount;
            	cout<<"\n\n\t -->>> Withdrawal is successful. -) New balance : $ "<<balance;
        	}
        	else if(amount<=0)
            	cout<<"\n\t *** Error : Invalid withdrawal amount. *** ";
        	else
            	cout<<"\n\n\t *** Error : Insufficient balance. *** ";
    	}

    	void display_Acc_Info()
    	{
        	cout<<"\n\n\t --> Account Number : "<<a_Number;
        	cout<<"\n\n\t --> Balance : $ "<<balance;
    	}
};

main()
{
    int a_Number;
    double i_Balance;

    cout<<"\n\t |`-> Enter account number : ";
    cin>>a_Number;
    cout<<"\n\t |`-> Enter initial balance : ";
    cin>>i_Balance;

    B_Account account(a_Number, i_Balance);

    int choice;
    double amount;

    do{
        cout<<"\n\n\t 1. Deposit";
        cout<<"\n\t 2. Withdraw";
        cout<<"\n\t 3. Display Account Info";
        cout<<"\n\t 4. Exit";
        cout<<"\n\t------------------------";
        cout<<"\n\n\n\t --->> Enter your choice : ";
        cin>>choice;

        switch(choice)
        {
        	case 1:
            	cout<<"\n\t--------------------------------";
            	cout<<"\n\t |`-> Enter deposit amount : ";
            	cin>>amount;
            	account.deposit(amount);
            	break;
        	case 2:
            	cout<<"\n\t--------------------------------";
            	cout<<"\n\t |`-> Enter withdrawal amount : ";
            	cin>>amount;
            	account.withdraw(amount);
            	break;
        	case 3:
	            account.display_Acc_Info();
    	        break;
        	case 4:
            	cout<<"\n\t----------------------------";
            	cout<<"\n\n\t *** Exiting program. *** ";
	            break;
    	    default:
        	    cout<<"\n\t----------------------------";
            	cout<<"\n\n\t *** Invalid choice. *** ";
        }
    } while(choice!=4);
}
