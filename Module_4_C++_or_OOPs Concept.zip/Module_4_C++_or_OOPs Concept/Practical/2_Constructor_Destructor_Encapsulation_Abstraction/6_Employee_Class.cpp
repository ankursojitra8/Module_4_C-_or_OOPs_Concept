/*6. Write a C++ program to implement a class called Employee that has  private member variables for name, 
employee ID, and salary. Include member functions to calculate and set salary based on employee performance. 
Using of constructor.*/

#include<iostream>
#include<string>
using namespace std;

class Employee
{
	private:
    		string name;
    		int emp_ID;
    		double salary;
	
	public:
    		Employee(string n, int id, double s) : name(n), emp_ID(id), salary(s) {}

    		void setSalary(double perf_Rating)
			{
    	    	double increment=salary*(perf_Rating/100);
        		salary+=increment;
        		cout<<"\n\n\t Salary increased by "<<increment<<".\n\n\t New salary: "<<salary<<endl;
	    	}
	
    		void displayInfo()
			{
				cout<<"\n\n\t ------------------------------";
	        	cout<<"\n\n\t --> Name : "<<name;
    	    	cout<<"\n\n\t --> Employee ID : "<<emp_ID;
        		cout<<"\n\n\t --> Salary : $"<<salary;
    		}
};

main()
{
    string name;
    int emp_ID;
    double salary, perf_Rating;

    cout<<"\n\t |`-> Enter employee name : ";
    getline(cin, name);
    cout<<"\n\t |`-> Enter employee ID : ";
    cin>>emp_ID;
    cout<<"\n\t |`-> Enter initial salary : ";
    cin>>salary;

    Employee employee(name, emp_ID, salary);

    cout<<"\n\t |`-> Enter performance rating (percentage %) : ";
    cin>>perf_Rating;

    employee.setSalary(perf_Rating);
    employee.displayInfo();
}

