/* 3. Write a C++ program to create a class called Car that has private  member variables for company, model, 
and year. Implement member functions to get and set these variables.*/

#include<iostream>
#include<string>
using namespace std;

class Car
{
	private:
    		string comp;
    		string model;
    		int year;

	public:
    		void setcomp(string c)
			{
        		comp=c;
    		}

    		string getcomp()
			{
        		return comp;
    		}

    		void setModel(string m)
			{
	        	model=m;
    		}

    		string getModel()
			{
    	    	return model;
    		}

    		void setYear(int y)
			{
    	    	year=y;
    		}

	    	int getYear()
			{
        		return year;
    		}
};

main()
{
    Car myCar;

    myCar.setcomp("Toyota");
    myCar.setModel("Supra");
    myCar.setYear(1980);

    cout<<"\n\n\t *** Car Information *** ";
    cout<<"\n\t---------------------------";
    cout<<"\n\n\t --> Company : " << myCar.getcomp();
    cout<<"\n\n\t --> Model : " << myCar.getModel();
    cout<<"\n\n\t --> Year : "<<myCar.getYear();
}
