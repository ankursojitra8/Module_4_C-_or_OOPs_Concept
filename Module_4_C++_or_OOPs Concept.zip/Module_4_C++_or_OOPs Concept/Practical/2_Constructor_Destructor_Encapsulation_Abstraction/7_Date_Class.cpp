/* 7. Write a C++ program to implement a class called Date that has private  member variables 
for day, month, and year. Include member functions to set and get these variables, as well as
to validate if the date is valid.*/

#include<iostream>
using namespace std;

class Date
{
	private:
    		int day, month, year;

	public:
    		Date(int d, int m, int y)
			{
        		setDay(d);
	        	setMonth(m);
    	    	setYear(y);
    		}

	    	void setDay(int d)
			{
        		if(d>=1&&d<=31)
            		day=d;
	        	else
				{
        	    	cout<<"\n\n\t *** Error Found : Invalid day *** ";
            		day=1;
        		}
    		}

	    	void setMonth(int m)
			{
    	    	if(m>=1&&m<=12)
	            	month=m;
    	    	else
				{
    		        cout<<"\n\n\t *** Error Found : Invalid month *** ";
		            month=1;
    	    	}
    		}

    		void setYear(int y)
			{
		        year=y;
    		}

		    int getDay() const
			{
        		return day;
		    }

		    int getMonth() const
			{
        		return month;
		    }

		    int getYear() const
			{
        		return year;
    		}

    		void displayDate() const
			{
    			cout<<"\n\n\t ------------------------------------------------\n\n\t -->> ";
        		cout<<day<<"/"<<month<<"/"<<year;
    		}
};

main()
{
    int d, m, y;
    cout<<"\n\t |`-> Enter day, month, and year : ";
    cin>>d>>m>>y;

    Date date(d, m, y);
    date.displayDate();
}

