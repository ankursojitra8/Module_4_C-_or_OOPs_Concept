// 2. WAP of Addition, Subtraction, Division, Multiplication using constructor.

#include<iostream>
using namespace std;

class Calculator
{
	public:
    		int n1, n2;

    		Calculator(int a, int b)
			{
    	    	n1=a;
        		n2=b;
	    	}

    		int add()
			{
	        	return n1+n2;
    		}

	    	int subtract()
			{
        		return n1-n2;
	    	}

    		int multiply()
			{
        		return n1*n2;
	    	}

    		double divide()
			{
        		if(n2==0)
				{
    	        	cout<<"\n\n\t *** Error Found : Division by zero ***";
        	    	return 0;
        		}
				else
    	        	return static_cast<double>(n1)/n2;
    		}
};

main()
{
    int a, b;

    cout<<"\n\n\t Enter two nbers : ";
    cin>>a>>b;

    Calculator calc(a, b);

    cout<<"\n\n\t -------------------------------------";
    cout<<"\n\n\t --> Addition : "<<calc.add();
    cout<<"\n\n\t --> Subtraction : "<<calc.subtract();
    cout<<"\n\n\t --> Multiplication : "<<calc.multiply();
    cout<<"\n\n\t --> Division : "<<calc.divide();
}
