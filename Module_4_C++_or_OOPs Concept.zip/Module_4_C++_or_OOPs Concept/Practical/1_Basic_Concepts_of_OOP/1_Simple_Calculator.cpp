// 1. WAP to create simple calculator using class

#include<iostream>
using namespace std;

class Calculator
{
public:
    	double add(double a, double b)
		{return a+b;}
    	double subtract(double a, double b)
		{return a-b;}
    	double multiply(double a, double b)
		{return a*b;}
    	double divide(double a, double b)
		{return (b!=0)?a/b:0;}
};

main()
{
    Calculator calc;
    char op;
    double a, b;
    cout<<"\n\n\t --> Enter two numbers and an operator [ex.,(1 + 1)] : ";
    cin>>a>>op>>b;
    switch (op)
	{
        case '+':
		cout<<a<<"+"<<b<<"="<<calc.add(a, b)<<endl;
		break;
        case '-':
		cout<<a<<"-"<<b<<"="<<calc.subtract(a, b)<<endl;
		break;
        case '*':
		cout<<a<<"*"<<b<<" = "<<calc.multiply(a, b)<<endl;
		break;
        case '/':
		cout<<a<<"/"<<b<<" = "<<calc.divide(a, b)<<endl;
		break;
        default: cout<<"\n\n\n\t *** Invalid operator ***"<<endl;
    }
}

