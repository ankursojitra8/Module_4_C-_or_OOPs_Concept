/* 2. Define a class to represent a bank account. Include the following members:
*** Data Member ***
-Name of the depositor
-Account Number
-Type of Account
-Balance amount in the account

*** Member Functions ***
-To assign values
-To deposited an amount
-To withdraw an amount after checking balance
-To display name and balance */

#include<iostream>
#include<string>
using namespace std;

class BankAccount
{
public:
    	string name;
    	int accountNumber;
    	string accountType;
    	double balance;

    	BankAccount(string n="Ankur Sojitra", int accNum='937580454088', string accType="Current", double bal=80000)
		{
        	name=n;
        	accountNumber=accNum;
        	accountType=accType;
        	balance=bal;
    	}

    	void deposit()
		{
        	double amount;
        	cout<<"\n\t -> Enter deposit amount : ";
        	cin>>amount;
        	balance+=amount;
        	cout<<"\n  |";
			cout<<"\n  |";
        	cout<<"\n   `~> Amount is Succesfully deposited : $ "<<amount;
    	}

    	void withdraw()
		{
        	double amount;
        	cout<<"\n\n\t -> Enter withdrawal amount : ";
        	cin>>amount;
        	if(amount<=balance)
			{
            	balance-=amount;
        		cout<<"\n  |";
				cout<<"\n  |";
        		cout<<"\n   `~> Amount is Succesfully withdrawn : $ "<<amount;
        	}
			else
            	cout<<"\n\t * Insufficient balance *";
    	}

    	void display()
		{
        	cout<<"\n\t ---------------------------------- ACCOUNT DETAILS ----------------------------------";
        	cout<<"\n\n\t\t\t\t\t Name :"<<name;
        	cout<<"\n\t\t\t\t\t Account Number : "<<accountNumber;
        	cout<<"\n\t\t\t\t\t Account Type : "<<accountType;
        	cout<<"\n\t\t\t\t\t --------------------------";
        	cout<<"\n\n\t\t\t\t\t Balance : $ "<<balance;
    	}
};

main()
{
    BankAccount account;

    int choice;
    do{
        cout<<"\n\n\n\t *** Please Select for Transaction *** ";
        cout<<"\n\n\t 1. Deposit";
        cout<<"\n\t 2. Withdraw";
        cout<<"\n\t 3. Display Acc Details & Balance";
        cout<<"\n\t 4. Exit";
        cout<<"\n\n\t --> Enter number for your choice : ";
        cin>>choice;

        switch(choice)
		{
            case 1:
                account.deposit();
                break;
            case 2:
                account.withdraw();
                break;
            case 3:
                account.display();
                break;
            case 4:
                cout<<"\n\n\t *** Exiting program... ***";
                break;
            default:
                cout<<"\n\n\t *** Invalid choice ***";
        }
    } while(choice!=4);
}

